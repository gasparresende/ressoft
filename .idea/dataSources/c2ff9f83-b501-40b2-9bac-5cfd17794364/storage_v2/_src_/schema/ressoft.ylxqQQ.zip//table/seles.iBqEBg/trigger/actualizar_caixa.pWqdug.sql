create definer = resende@`%` trigger actualizar_caixa
    after insert
    on seles
    for each row
BEGIN
    
    UPDATE caixas SET saldo = saldo + new.total;
    END;

