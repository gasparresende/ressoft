create definer = resende@`%` trigger transferencias_after_insert
    after insert
    on transferencias
    for each row
BEGIN
                INSERT INTO saidas
                    (products_id, shops_id, sizes_id, colors_id, marcas_id, categorias_id, qtd, validade, DATA, obs, users_id, hora)
                VALUES
                    (new.products_id, new.origem, new.sizes_id, new.colors_id, new.marcas_id, new.categorias_id, new.qtd, new.validade, new.data, "Saidass de Transferência", new.users_id, now());

                INSERT INTO entradas
                    (products_id, shops_id, sizes_id, colors_id, marcas_id, categorias_id, qtd, validade, DATA, obs, users_id, hora)
                VALUES
                    (new.products_id, new.destino, new.sizes_id, new.colors_id, new.marcas_id, new.categorias_id, new.qtd, new.validade, new.data, "Entradas de Transferência", new.users_id, now());
            END;

