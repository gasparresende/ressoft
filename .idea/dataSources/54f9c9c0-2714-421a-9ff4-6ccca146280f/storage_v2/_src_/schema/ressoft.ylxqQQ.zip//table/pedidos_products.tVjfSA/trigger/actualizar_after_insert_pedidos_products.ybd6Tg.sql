create definer = resende@`%` trigger actualizar_after_insert_pedidos_products
    after insert
    on pedidos_products
    for each row
BEGIN
                UPDATE inventories set qtd = qtd - NEW.qtd
                where id = new.inventories_id;
	        END;

