create definer = root@localhost trigger actualizar_after_insert_saidass
    after insert
    on saidas
    for each row
BEGIN
                CALL actualizar_stock(new.shops_id, new.sizes_id, new.colors_id, new.marcas_id,
	                new.categorias_id, new.products_id, new.qtd*(-1), new.validade);
            END;

