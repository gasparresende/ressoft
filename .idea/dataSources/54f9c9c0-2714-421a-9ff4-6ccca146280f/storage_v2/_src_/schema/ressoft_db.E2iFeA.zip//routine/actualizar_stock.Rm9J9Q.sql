create
    definer = root@localhost procedure actualizar_stock(IN shops_id2 int, IN sizes_id2 int, IN colors_id2 int,
                                                        IN marcas_id2 int, IN categorias_id2 int, IN products_id2 int,
                                                        IN qtd2 int, IN validade2 date)
BEGIN
                DECLARE inventories_id INT(11);

                SELECT id INTO inventories_id
                FROM inventories
                WHERE products_id = products_id2
                  AND shops_id = shops_id2
                  AND (sizes_id = sizes_id2 OR sizes_id IS NULL AND sizes_id2 IS NULL)
                  AND (colors_id = colors_id2 OR colors_id IS NULL AND colors_id2 IS NULL)
                    AND (marcas_id = marcas_id2 OR marcas_id IS NULL AND marcas_id2 IS NULL)
                    AND (categorias_id = categorias_id2 OR categorias_id IS NULL AND categorias_id2 IS NULL)
                    AND (validade = validade2 OR validade IS NULL AND validade2 IS NULL);


                 IF inventories_id IS NOT NULL THEN
                    UPDATE inventories
                    SET qtd = qtd + qtd2
                    WHERE id = inventories_id;
                ELSE
                    INSERT INTO inventories(products_id, qtd, shops_id, sizes_id, colors_id, marcas_id, categorias_id, validade)
                    VALUES (products_id2, qtd2, shops_id2, sizes_id2, colors_id2, marcas_id2, categorias_id2, validade2);
                END IF;
            END;

