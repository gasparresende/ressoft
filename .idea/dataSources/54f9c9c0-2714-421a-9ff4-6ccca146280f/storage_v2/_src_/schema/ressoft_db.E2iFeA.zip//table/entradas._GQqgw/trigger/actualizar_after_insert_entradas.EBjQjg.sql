create definer = root@localhost trigger actualizar_after_insert_entradas
    after insert
    on entradas
    for each row
BEGIN
                CALL actualizar_stock(new.shops_id, new.sizes_id, new.colors_id, new.marcas_id,
	                new.categorias_id, new.products_id, new.qtd, new.validade);
	        END;

